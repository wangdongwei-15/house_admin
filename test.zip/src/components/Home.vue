<template>
  <div class="home-container">
     <h1>home</h1>
  </div>
</template>

<script>

export default {
  name: 'home',
  data(){
     return {
     
     }
  },

  created(){

  },

  methods: {


  }
}
</script>

<style lang="less" scoped>


</style>
