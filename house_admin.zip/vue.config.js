module.exports = {
    devServer: {
      proxy: 'http://127.0.0.1/jinqi_api/public/index.php/api/'
    }
  }