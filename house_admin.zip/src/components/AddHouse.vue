<template>
    <div class="add-house-container">

        

       <el-breadcrumb separator="/">
            <el-breadcrumb-item :to="{ path: '/' }">首页</el-breadcrumb-item>
            <el-breadcrumb-item>房源管理</el-breadcrumb-item>
            <el-breadcrumb-item>创建房源</el-breadcrumb-item>
        </el-breadcrumb>

        <el-card>

            <el-row>
            <el-col :span="18">
                <el-form ref="addFormRef" :model="house" label-width="80px">
                <el-form-item label="房源标题">
                    <el-input v-model="house.title"></el-input>
                </el-form-item>
                 <el-form-item label="房源详情">
                    <el-input type="textarea" v-model="house.des"></el-input>
                </el-form-item>
                 <el-form-item label="姓名">
                    <el-input v-model="house.name"></el-input>
                </el-form-item>
                 <el-form-item label="手机号码">
                    <el-input v-model="house.tel"></el-input>
                </el-form-item>
                

                <el-form-item>
                    <el-upload
                        multiple
                        ref='upload'
                        :auto-upload="false"
                        :http-request="uploadFile"
                        action="https://jsonplaceholder.typicode.com/posts/"
                        list-type="picture-card"
                        :on-preview="handlePictureCardPreview"
                        :on-remove="handleRemove">
                        <i class="el-icon-plus"></i>
                        </el-upload>
                        <el-dialog :visible.sync="dialogVisible">
                        <img width="100%" :src="dialogImageUrl" alt="">
                        </el-dialog>
                </el-form-item>

                <el-form-item>
                    <el-button type="primary" @click="saveHouse">立即创建</el-button>
                    <el-button>取消</el-button>
                </el-form-item>

            </el-form>  
            </el-col>   
            </el-row> 

              

        </el-card> 

    </div>
</template>

<script>
export default {
    data(){

        return {
            house:{
                title:'',
                des:'',
                name:'',
                tel:''
            },
            formData:{},
            dialogVisible:false,
            dialogImageUrl:''
        }

    },

    methods:{

        uploadFile(img){
            this.formData.append("pic[]",img.file);
        },

        handlePictureCardPreview(img){
           console.log(img);
           this.dialogImageUrl = img.url;
           this.dialogVisible = true;
        },

        handleRemove(img){
            console.log(img);
        },
        
         saveHouse(){



         // 1 创建空的表单对象;
          this.formData = new FormData();

         // 2 手动上传逻辑
         this.$refs.upload.submit();

         return false;

          // 3 将表单数据追加到formData表单对象中;
          this.formData.append("form",JSON.stringify(this.house));

          this.$http.post('house/add',this.formData).then(res=>{
              console.log(res);
          });
             
         }
    }
}
</script>

<style lang="less" scoped>

</style>